//
//  MoveWareApp.swift
//  MoveWare
//
//  Created by Alumno on 26/02/24.
//

import SwiftUI

@main
struct MoveWareApp: App {
    var body: some Scene {
        WindowGroup {
            PanelView()
        }
    }
}
