//
//  List.swift
//  Mock
//
//  Created by Nats Salgado on 26/02/24.
//

import SwiftUI

struct List: View {
    var body: some View {
        
}

#Preview {
    List()
}
