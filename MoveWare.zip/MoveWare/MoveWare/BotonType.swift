//
//  BotonType.swift
//  MoveWare
//
//  Created by Alumno on 27/02/24.
//

import Foundation
import SwiftUI

struct Type: Hashable, Identifiable, Codable {
    
    var id : Int
    var name : String
    var window : String
    
    private var vistaNombre: String


    
    
}


